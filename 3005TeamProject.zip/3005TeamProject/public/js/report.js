let reportE = document.getElementById("report1-div");
function showReport(){
    reportE.setAttribute("style", "display: flex;");
}
function closeReport(){
    reportE.setAttribute("style", "display: none;");

}